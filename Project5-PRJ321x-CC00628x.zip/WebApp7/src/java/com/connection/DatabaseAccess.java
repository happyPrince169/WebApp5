/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Lenovo
 */
public class DatabaseAccess {

    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        // JDBC driver name and database URL
        
        String DB_URL = "jdbc:mysql://localhost/webapp7";

        //  Database credentials
        String USER = "root";
        String PASS = "lumiao0709";
        Connection conn = null;
        try {
            // Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");
            // Open a connection
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }


}
