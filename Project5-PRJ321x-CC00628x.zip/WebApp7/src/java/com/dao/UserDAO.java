/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.connection.DatabaseAccess;
import com.entities.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Lenovo
 */
public class UserDAO implements UserInterface {

    User u = new User();

    @Override
    public void save(User u) {

        PreparedStatement insertUser = null;

        String insertString = "INSERT INTO webapp7.users (Username, Password ) VALUES (?, ?)";

        try {
            Connection conn = DatabaseAccess.getConnection();
            insertUser = conn.prepareStatement(insertString);

            insertUser.setString(1, u.getUsername());
            insertUser.setString(2, u.getPassword());
            insertUser.executeUpdate();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public User searchUser(String username, String password) {
        PreparedStatement selectUser = null;
        ResultSet r = null;
        String selectString = "SELECT * from webapp7.users where Username=? and Password=?";
        try {
            Connection conn = DatabaseAccess.getConnection();
            selectUser = conn.prepareStatement(selectString);
            selectUser.setString(1, username);
            selectUser.setString(2, password);
            r = selectUser.executeQuery();
            if (r.next()) {
                u.setUserID(r.getInt("UserID"));
                u.setUsername(r.getString("Username"));
                u.setPassword(r.getString("Password"));
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return u;
    }

}
