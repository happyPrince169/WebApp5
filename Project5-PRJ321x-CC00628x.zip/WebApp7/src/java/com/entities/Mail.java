/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entities;

/**
 *
 * @author Lenovo
 */
public class Mail {

    private String from;
    private String to;
    private String cc;
    private String subject;
    private String message;

    public Mail() {
        this.from = "";
        this.to = "";
        this.cc = "";
        this.subject = "";
        this.message = "";
    }

    public Mail(String f, String t, String s, String m, String cc) {
        this.from = f;
        this.to = t;
        this.cc = cc;
        this.subject = s;
        this.message = m;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getCc() {
        return cc;
    }

    public void setCc(String cc) {
        this.cc = cc;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
